﻿namespace CarteDeCredit.API.Interfaces
{
    public interface IGenerateurNumeroCarte
    {
        public string GenererNumeroCarte(string typeCarte);
    }
}
